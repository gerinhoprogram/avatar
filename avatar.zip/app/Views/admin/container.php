<div class="container py-5">

    <div class="row">
        <div class="col-lg-3">
            <?php include 'sideBar.php' ?>
        </div>
        <div class="col-lg-9 border p-3">



        </div>
    </div>

</div>