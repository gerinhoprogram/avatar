<div class="sideBar admin">
                <h4>Posts</h4>
                <ul>
                    <li>
                        <a href="<?=URL?>/admin/cadastrar/post" data-toggle="tooltip" title="Cadastrar Posts">
                            <i class="far fa-edit"></i> Cadastrar
                        </a>
                    </li>
                    <li>
                        <a href="<?=URL?>/admin/listar/posts" data-toggle="tooltip" title="Listar Posts">
                            <i class="fas fa-list"></i> Listar
                        </a>
                    </li>

                    <li>
                        <a href="<?=URL?>/cria_avatar" data-toggle="tooltip" title="Listar Posts">
                            <i class="fas fa-list"></i> Avatar
                        </a>
                    </li>

                    <li>
                        <a href="<?=URL?>/jogo_memoria" data-toggle="tooltip" title="Listar Posts">
                            <i class="fas fa-list"></i> Jogo da memória
                        </a>
                    </li>

                </ul>
            </div>