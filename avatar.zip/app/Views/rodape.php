<footer class="p-5 text-light">
    <div class="container">

        <small>
            <div class="row border-top py-2 mt-3">
                <div class="col-md-9">
                    &COPY; Copyright - <?= date('Y') ?> Todos os Direito Reservados. <?= APP_NOME ?> Rogério Furquim
                </div>
                <div class="col-md-3 text-right">
                    Versão: <?= APP_VERSAO ?>
                </div>
            </div>
        </small>
    </div>
</footer>