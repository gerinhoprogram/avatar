<?php
/*
 * Arquivo de configuração
 */

 const DB = [
    'HOST' => 'rogerioweb.com',
    'USUARIO' => 'u281483592_framework_2_0',
    'SENHA' => '@Framework-2.0',
    'BANCO' => 'u281483592_framework_2_0',
    'PORTA' => '3306'
 ];

// __FILE__  — Constante Mágica. Retorna o caminho completo e o nome do arquivo
// dirname — Retorna o caminho/path do diretório pai

//define e const — Define uma constante. As constantes não podem ser alteradas depois de declaradas.
define('APP', dirname(__FILE__));

define('URL','http://rogerioweb.com/site_painel/avatar');

define('APP_NOME','Super posts');

const APP_VERSAO = '1.7.0';
